package com.peaksoft.entity;

public enum StudyFormat {
    ONLINE,
    OFFLINE

}
