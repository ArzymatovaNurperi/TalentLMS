package com.peaksoft.controller;

public class StudentController {
}
